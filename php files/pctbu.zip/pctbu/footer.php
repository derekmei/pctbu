<div class="footer">
	
	<div class="footer-motto-text text-center">“May the Candle of Knowledge Guide our Ship to Achievement”</div>

	<div class="footer-social row">
		<div class="col-sm-6 col-sm-offset-3">
			<div class="row">
				<div class="col-xs-2"></div>
				<div class="col-xs-2 img-center">
					<img src="<?php bloginfo('template_directory');?>/img/linkedin-footer.png" class="img-center footer-social-icon">
				</div>
				<div class="col-xs-2 img-center">
					<img src="<?php bloginfo('template_directory');?>/img/twitter-footer.png" class="img-center footer-social-icon">
				</div>
				<div class="col-xs-2 img-center">
					<img src="<?php bloginfo('template_directory');?>/img/facebook-footer.png" class="img-center footer-social-icon">
				</div>
				<div class="col-xs-2 img-center">
					<img src="<?php bloginfo('template_directory');?>/img/instagram-footer.png" class="img-center footer-social-icon">
				</div>
			</div>
		</div>
	</div>

	
	<div class="footer-grey-text text-center">Boston University Zeta Chapter | ©2015 Derek Mei</div>
</div>

<!--JQUERY SCRIPTS-->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
</body>
</html>