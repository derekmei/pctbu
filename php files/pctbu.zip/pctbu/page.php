<?php get_header(); ?>

<div class="container-fluid members">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-8 member-grid">
            <h2 class="black-div-title text-center"><?php if(is_page( 'eboard' )) : echo 'Executive Board'; elseif(is_page( 'alpha' )) : echo 'Alpha Class'; elseif(is_page( 'beta' )) : echo 'Beta Class'; elseif(is_page( 'theta' )) : echo 'Theta Class'; endif; ?></h2>
    </div>
    </div>
    <div class="col-sm-3 member-nav-container">
        <ul class="member-nav">
            <li><a class="<?php if(is_page( 'eboard' )) : echo 'active-class'; else: echo '#'; endif; ?>" href="http://www.pctbu.com/eboard">Executive Board</a></li>
            <li><a class="<?php if(is_page( 'alpha' )) : echo 'active-class'; else: echo '#'; endif; ?>" href="http://www.pctbu.com/alpha">Alpha Class</a></li>
            <li><a class="<?php if(is_page( 'beta' )) : echo 'active-class'; else: echo '#'; endif; ?>" href="http://www.pctbu.com/beta">Beta Class</a></li>
            <li><a class="<?php if(is_page( 'theta' )) : echo 'active-class'; else: echo '#'; endif; ?>" href="http://www.pctbu.com/theta">Theta Class</a></li>
            <li><a class="<?php if(is_page( 'gamma' )) : echo 'active-class'; else: echo '#'; endif; ?>" href="http://www.pctbu.com/gamma">Gamma Class</a></li>
        </ul>
    </div>
    <div class="col-sm-8 member-grid">
        <?php $counter = 0; ?>
        <?php while( have_rows('members') ): the_row(); ?>
            <?php if($counter % 4 === 0) :    echo '<div class="row member-row">'; endif; ?>
            <div class="col-xs-6 col-md-3">
                <a href="<?php echo get_sub_field('linkedin'); ?>" target="_blank">
                    <img src="<?php echo get_sub_field('photo'); ?>" class="member-photo img-center">
                </a>
                <div class="member-name text-center"><?php echo get_sub_field('name'); ?></div>
                <div class="member-subfield text-center"><?php echo get_sub_field('school_and_year'); ?></div>
            </div>
            <?php if($counter % 4 === 3):    echo '</div>'; endif; ?>
            <?php $counter++; ?>
        <?php endwhile; ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>